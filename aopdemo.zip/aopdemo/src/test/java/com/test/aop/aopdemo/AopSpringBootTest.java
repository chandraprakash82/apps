package com.test.aop.aopdemo;

import org.junit.jupiter.api.Test;
//import org.junit.runner.RunWith;
import org.springframework.beans.factory.annotation.Autowired;
import org.springframework.boot.test.context.SpringBootTest;
import org.springframework.test.context.junit4.SpringRunner;

//@RunWith(SpringRunner.class)
@SpringBootTest
public class AopSpringBootTest 
{
	@Autowired
	private DomainService service;
	@Autowired
	private DomainServiceForAfter service2;
	
	@Autowired
	private DomainServiceForBefore service3;
	
	/*
	 * @Test public void testGetDomainObjectById() { service.getDomainObjId(10L); }
	 * 
	 * @Test public void testMethod2() { service.methods2(); }
	 */
	
	/*
	 * @Test public void testAfter() { service2.getMethodForAfter1(10L);
	 * service2.getMethodForAfter2(); }
	 */
	
	@Test
	public void testBeforer() {
		service3.getMethodForBefore1(10L);
		service3.getMethodForBefore2();
	}
}
