package com.test.aop.aopdemo;

import org.apache.logging.log4j.LogManager;
import org.apache.logging.log4j.Logger;
import org.aspectj.lang.JoinPoint;
import org.aspectj.lang.ProceedingJoinPoint;
import org.aspectj.lang.annotation.After;
import org.aspectj.lang.annotation.Around;
import org.aspectj.lang.annotation.Aspect;
import org.aspectj.lang.annotation.Before;
import org.aspectj.lang.reflect.MethodSignature;
import org.springframework.stereotype.Component;
import org.springframework.util.StopWatch;

@Aspect
@Component
public class LoggingAspect {

	private static final Logger logger =LogManager.getLogger();
	
	//@Around("execution(*com.test.aop..*(..)))")
	@Around("execution(* com.test.aop.aopdemo.DomainService.*(..)))")
	public Object profileAllMethods(ProceedingJoinPoint p) throws Throwable {
		MethodSignature ms = (MethodSignature) p.getSignature();
		String classname = ms.getDeclaringType().getSimpleName();
		String methodname = ms.getMethod().getName();
		final StopWatch sw = new StopWatch();
		//logger.info("classname "+classname+ "methodname"+methodname+" sw "+sw.getTotalTimeMillis());
		sw.start();
		logger.info("classname "+classname+ "methodname"+methodname+" sw "+sw.getTotalTimeMillis());
		Object result = p.proceed();
		sw.stop();
		
		logger.info("classname "+classname+ "methodname"+methodname+" sw "+sw.getTotalTimeMillis());
		
		return result;
	}
	
	@After("execution(* com.test.aop.aopdemo.DomainServiceForAfter.*(..)))")
	public void afterAdvice(JoinPoint jp) {
		logger.info("afterAdvice"+jp.getSignature().getName());
	}
	
	@Before("execution(* com.test.aop.aopdemo.DomainServiceForBefore.*(..)))")
	public void beforeAdvice(JoinPoint jp){
		logger.info("beforeAdvice "+jp.getSignature().getName());
	}
}
