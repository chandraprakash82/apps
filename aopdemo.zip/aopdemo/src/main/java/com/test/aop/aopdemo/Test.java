package com.test.aop.aopdemo;

import java.util.Arrays;
import java.util.Comparator;
import java.util.List;
import java.util.stream.Collectors;

public class Test {

	public static void main(String[] args) {
		// TODO Auto-generated method stub
		List<Integer> numList = Arrays.asList(34, 6, 3, 12, 65, 1, 8);
		List<Integer>finalList=numList.stream().filter(n->n>10).sorted().collect(Collectors.toList());
		System.out.println(finalList);
	}

}
