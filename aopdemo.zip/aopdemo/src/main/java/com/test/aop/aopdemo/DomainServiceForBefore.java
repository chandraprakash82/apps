package com.test.aop.aopdemo;

import java.util.Random;

import org.apache.logging.log4j.LogManager;
import org.apache.logging.log4j.Logger;
import org.springframework.stereotype.Service;
@Service
public class DomainServiceForBefore {
	private static final Logger logger = LogManager.getLogger();
	
	public Object getMethodForBefore1(Long id) {
		logger.info("getMethodForBefore1");
		try {
			 Thread.sleep(new Random().nextInt(2000));
		}catch(InterruptedException e) {
			
		}
		return id;
	}
	
	 public void getMethodForBefore2() {
		 try {
			 logger.info("getMethodForBefore2");
		 }catch(Exception ex) {
			 ex.printStackTrace();
		 }
	 }
}
