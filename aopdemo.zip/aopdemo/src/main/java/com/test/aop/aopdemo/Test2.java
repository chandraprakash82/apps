package com.test.aop.aopdemo;

public class Test2 {
	//Complete the function scramble(str1, str2) that returns true if a portion of str1 characters can be
	//rearranged to match str2, otherwise returns false.

//Notes:Only lower case letters will be used (a-z). No punctuation or digits will be included.
//Performance needs to be considered.

//Examples:
//scramble('rkqodlw', 'world') ==> True
//scramble('spartans', 'ttans') ==> False
//scramble('cambridge', 'steak') ==> False

	public static void main(String[] args) {
		// TODO Auto-generated method stub
			System.out.println(scramble("rkqodlw", "world"));
			System.out.println(scramble("spartans", "ttans"));
			System.out.println(scramble("cambridge", "steak"));
	}
	
	private static  boolean scramble(String str1, String str2) {

		for(int i=0; i<str2.length();i++) {

			if(!str1.contains(str2.subSequence(i, i+1))){
				return false;			
			}
		}
		return true;
		
	}

}
