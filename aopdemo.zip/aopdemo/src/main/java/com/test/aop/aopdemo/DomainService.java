package com.test.aop.aopdemo;

import java.util.Random;

import org.apache.logging.log4j.LogManager;
import org.apache.logging.log4j.Logger;
import org.springframework.stereotype.Service;
@Service
public class DomainService {
	private static final Logger logger = LogManager.getLogger();
	
	public Object getDomainObjId(Long id) {
		logger.info("getDomainObjId");
		try {
			 Thread.sleep(new Random().nextInt(2000));
		}catch(InterruptedException e) {
			
		}
		return id;
	}
	
	 public void methods2() {
		 try {
			 logger.info("methods2");
		 }catch(Exception ex) {
			 ex.printStackTrace();
		 }
	 }
}
