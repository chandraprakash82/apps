package com.photon.productservice.service;

import com.fasterxml.jackson.databind.ObjectMapper;
import com.photon.productservice.dto.Product;
import com.photon.productservice.entity.ProductEntity;
import com.photon.productservice.entity.ProductRepository;
import org.springframework.beans.factory.annotation.Autowired;
import org.springframework.stereotype.Service;

import java.util.ArrayList;
import java.util.List;

@Service
public class ProductService {

    @Autowired
    public ProductRepository productRepository;

    @Autowired
    ObjectMapper objectMapper;

    public void addProduct(Product product) {
        ProductEntity productEntity=objectMapper.convertValue(product,ProductEntity.class);
        productEntity.setId(product.getId());
        productRepository.save(productEntity);
    }

    public List<Product> getAllProduct(){
        List<Product> productList= new ArrayList<>();
        List<ProductEntity> productEntityList= productRepository.findAll();
        for(ProductEntity productEntity:productEntityList){
            Product product= objectMapper.convertValue(productEntity, Product.class);
            productList.add(product);
        }
        return productList;
    }

    public Product productById(Integer id){
        return objectMapper.convertValue(productRepository.findById(id), Product.class);
    }
}
