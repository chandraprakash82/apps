package com.photon.productservice.controller;

import com.photon.productservice.dto.Product;
import com.photon.productservice.service.ProductService;
import org.springframework.beans.factory.annotation.Autowired;
import org.springframework.http.ResponseEntity;
import org.springframework.web.bind.annotation.*;

import java.util.List;

@RestController
@RequestMapping("/product")
public class ProductController {

    @Autowired
    public ProductService productService;

    @PostMapping("/addproduct")
    public ResponseEntity<String> addProduct(@RequestBody Product product){
                productService.addProduct(product);
                return ResponseEntity.ok("Product has been added successfully");
    }

        @GetMapping("/allproducts")
    public List<Product> getAllProducts(){
       return productService.getAllProduct();
    }

    @GetMapping("/{id}")
    public Product getAllProducts(@PathVariable Integer id){
        return productService.productById(id);
    }

}
