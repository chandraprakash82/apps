package com.photon.orderservice.controller;

import com.photon.orderservice.dto.Order;
import com.photon.orderservice.service.OrderService;
import org.springframework.beans.factory.annotation.Autowired;
import org.springframework.http.ResponseEntity;
import org.springframework.web.bind.annotation.PostMapping;
import org.springframework.web.bind.annotation.RequestBody;
import org.springframework.web.bind.annotation.RequestMapping;
import org.springframework.web.bind.annotation.RestController;

import java.time.LocalDate;
import java.util.List;

@RestController
@RequestMapping("/order")
public class OrderController {

    @Autowired
    public OrderService orderService;

    @PostMapping("/createorder")
    public ResponseEntity<String> createOrder(@RequestBody Order order){
        orderService.creatOrder(order);
      return  ResponseEntity.ok("order created successfully");
    }


}
