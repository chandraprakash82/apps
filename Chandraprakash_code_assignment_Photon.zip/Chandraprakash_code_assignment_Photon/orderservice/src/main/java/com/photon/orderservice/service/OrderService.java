package com.photon.orderservice.service;

import com.fasterxml.jackson.databind.ObjectMapper;
import com.photon.orderservice.dto.Order;
import com.photon.orderservice.entity.OrderEntity;
import com.photon.orderservice.entity.OrderRepository;
import org.springframework.beans.factory.annotation.Autowired;
import org.springframework.stereotype.Service;

@Service
public class OrderService {

    @Autowired
    public OrderRepository orderRepository;

    @Autowired
    public ObjectMapper objectMapper;

    public String creatOrder(Order order){
        OrderEntity orderEntity=objectMapper.convertValue(order,OrderEntity.class);
        orderEntity.setId(order.getId());
        orderRepository.save(orderEntity);
        return "order created";
    }
}
