package com.photon.orderservice.entity;

import jakarta.persistence.*;
import lombok.AllArgsConstructor;
import lombok.Data;
import lombok.NoArgsConstructor;


import java.io.Serializable;
import java.time.LocalDate;
import java.util.Date;


@Entity
@Table(name = "CUSTOMER_ORDER")
@Data
@AllArgsConstructor
@NoArgsConstructor
public class OrderEntity implements Serializable {

    @Id
    @Column(name="ID")
    private Integer id;

    @Column(name="CUSTOMERNAME")
    private String customerName;

    @Column(name="ORDERDATE")
    private Date orderDate;

}
