package com.test.firstProject;

import java.util.ArrayList;
import java.util.List;

import org.springframework.web.bind.annotation.GetMapping;
import org.springframework.web.bind.annotation.RestController;

@RestController
public class BooksController {

	@GetMapping("\books")
	public List<Books> getBooks(){
		List<Books> lists = new ArrayList<Books>();
		lists.add(new Books(1l,"book1","chandra"));
		lists.add(new Books(2l,"book2","chandra"));
		lists.add(new Books(3l,"book3","chandra"));
		return lists;
				 
	}
}
