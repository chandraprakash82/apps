package com.test.firstProject;

public class Books {

	private Long id;
	private String name;
	private String auther;
	
	public Long getId() {
		return id;
	}
	public void setId(Long id) {
		this.id = id;
	}
	public String getName() {
		return name;
	}
	public void setName(String name) {
		this.name = name;
	}
	public String getAuther() {
		return auther;
	}
	public void setAuther(String auther) {
		this.auther = auther;
	}
	public Books(Long id, String name, String auther) {
		super();
		this.id = id;
		this.name = name;
		this.auther = auther;
	}
	@Override
	public String toString() {
		return "Books [id=" + id + ", name=" + name + ", auther=" + auther + "]";
	}
	
	
	
}
